CREATE VIEW v_aim_client AS
  SELECT
    `c`.`id`              AS `id`,
    `c`.`name`            AS `name`,
    `c`.`client_level_id` AS `level`,
    `c`.`client_id`       AS `client_termi_id`,
    `d`.`name`            AS `client_termi_level_name`
  FROM (`erp180301`.`t_client` `c`
    JOIN `erp180301`.`t_data_dict` `d` ON ((`c`.`client_level_id` = `d`.`id`)))
  WHERE (`c`.`is_client` = 'Y')
  UNION SELECT
          `t`.`id`                    AS `id`,
          `t`.`termi_name`            AS `name`,
          `t`.`termi_client_level_id` AS `level`,
          `t`.`termi_client_id`       AS `client_termi_id`,
          `d`.`name`                  AS `client_termi_level_name`
        FROM (`erp180301`.`t_termi_client` `t`
          JOIN `erp180301`.`t_data_dict` `d` ON ((`t`.`termi_client_level_id` = `d`.`id`)))
        WHERE (`t`.`is_termi_client` = 'Y');

